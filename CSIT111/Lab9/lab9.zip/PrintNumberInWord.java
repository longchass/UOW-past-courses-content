public class PrintNumberInWord
{
	public static void main (String[] args)
	{
		int variable = Integer.parseInt(args[0]);
		if(variable==1)
		System.out.println("ONE");
		else if(variable==2)
		System.out.println("TWO");
		else if(variable==3)
		System.out.println("THREE");
		else if(variable==4)
		System.out.println("FOUR");
		else if(variable==5)
		System.out.println("FIVE");
		else if(variable==6)
		System.out.println("SIX");
		else if(variable==7)
		System.out.println("SEVEN");
		else if(variable==8)
		System.out.println("EIGHT");
		else if(variable==9)
		System.out.println("NINE");
		else
		System.out.println("OTHER");
	}
	
	
}