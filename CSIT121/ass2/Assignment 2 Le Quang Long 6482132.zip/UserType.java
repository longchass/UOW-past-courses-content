public enum UserType {
	
	
	
	
	Customer, VIP, Guest, Staff;
		public String returnType()
	{
		
		return this.toString();
		
	}

};