import java.lang.*;
public enum State
{

	NSW,WA,CA,NA,SA,QLD,VIC,TAS;

		public String returnType()
	{
		return this.toString();
	}
};