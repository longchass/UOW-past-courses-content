public interface ProductInformation
{
	public String getProductDescription();

	public String getDetail();

}