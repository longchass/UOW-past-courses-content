public interface ShopingCart
{
	
	public double getPricePerUnit();

	public String getUnitDescription();

	public String getProductID();

}