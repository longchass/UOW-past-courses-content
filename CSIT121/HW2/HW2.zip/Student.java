import java.util.*;
public class Student extends SchoolUser
{

	Student(String id, String First, String Last, String username, String Pass, UserType user, Boolean value,  String grade, String schoolname , String CLASS)
	{
		
		super(id,First, Last, username, Pass, UserType.Student, value, grade, schoolname, CLASS);

	try{
			if(id.charAt(0) == '1' && id.length() == 7)
			{

			}
			else {
				throw new NullPointerException();
			}
		}
		catch (NullPointerException e)
		{
			System.out.println(" this is not a Student ID or maybe this is not a 7 digit ID");
		}
		
	}
	@Override
	public void setPermission(PermissionType input)
	{
		if (input == PermissionType.Test || input == PermissionType.None) {
			super.setPermission(input);
		}
		else {
			System.out.println("you can't set this level of permission for a Student account");
		}
	}
		@Override
	protected void setid(String input)
	{
			if(input.charAt(0) == '1' && input.length() == 7)
			{
					super.setid(input);
			}
			else {
				System.out.println("This id Can't be set to a Student");
				}
	}

}