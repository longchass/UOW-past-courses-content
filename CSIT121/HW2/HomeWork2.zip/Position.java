public enum Position {
	
	
	
	
	NormalTeacher, HeadTeacher, SubtitudeTeacher;
	public String returnType()
	{
		
		return this.toString();
		
	}
};