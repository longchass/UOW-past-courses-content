enum UserType {
	
	
	
	
	Student, Teacher, Parent;
	public String returnType()
	{
		
		return this.toString();
		
	}
};