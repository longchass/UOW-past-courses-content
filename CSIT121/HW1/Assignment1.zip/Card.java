import java.text.SimpleDateFormat;  
import java.util.Date;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Locale;
import static java.util.Calendar.*;
import java.util.Date;
import java.lang.String.*;
import static java.lang.Math.abs;
//import all the necessary modules



public class Card
{
//initialise all necessary variables
	private String id;
	private String name;

//Calendar to get the current date
	private Calendar creationCalendar = Calendar.getInstance();

	private Date createddate = null;
	protected int years;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

	
	private address full;
	
	private int balance;
	
	protected double discount;
	
	private double coupon;
	protected double couponRate;
	
	protected String CardType;
	
	protected StringBuilder fullDetail = new StringBuilder();
//no parameter constructor just in case
	public Card ()
	{
		
	}
	
//constructor for the class card
	public Card (String id, String name, String date, address address, int balance)
	{
			this.id = id;
			this.balance = balance;
			this.name = name;
			full = address;
			Calendar todaycalendar = Calendar.getInstance();
			Date today = todaycalendar.getTime();
			try {
				createddate = dateFormat.parse(date);
			} catch (ParseException e) {
				System.out.println("error can't parse");
			}
			creationCalendar.setTime(createddate);

			years = Math.round((((todaycalendar.getTimeInMillis() - creationCalendar.getTimeInMillis())/ (24 * 60 * 60 * 1000)) / 356));
	}

	public String toString()
	{
		
	    
		fullDetail.append("Your card id is " + id).append(System.getProperty("line.separator"));
		fullDetail.append("Your name is " + name).append(System.getProperty("line.separator"));
		fullDetail.append("You have spent " + balance).append(System.getProperty("line.separator"));
		fullDetail.append("This card was created on " + dateFormat.format(createddate)).append(System.getProperty("line.separator"));
		fullDetail.append("You have been with us for " + years + " years").append(System.getProperty("line.separator"));
		fullDetail.append("Your discount for each purchase is " + discount*100 + "%").append(System.getProperty("line.separator"));
		fullDetail.append("Your full address is " + full).append(System.getProperty("line.separator"));
		fullDetail.append("Your card type is " + CardType).append(System.getProperty("line.separator"));
		fullDetail.append("Your coupon is " + Math.round(coupon) + "$").append(System.getProperty("line.separator"));
		return fullDetail.toString();
		//return (id + "\r\n" + name + " " + years + " " + balance + " " + type );		
	}
	public double getDiscount()
	{
		return discount;
	}

	public double getBalance()
	{
		return balance;
	}
	public String getID()
	{
		return id;
	}
		public void calCoupon()
	{
		coupon = balance*couponRate;
	}
	public double getCouponRate()
	{
	 return couponRate;	
	}
		public int getYear()
	{
		return years;
	}
		public void printCoupon()
	{
		System.out.println(this);
	}
}