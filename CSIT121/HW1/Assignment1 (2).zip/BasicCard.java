//adding Basic card subclass
public class BasicCard extends Card
{
	private static final int annualfee = 5;
	
//add BasicCard constructor
	public BasicCard (String id, String name, String date, address address, int balance)
	{
		//calling the parent constructor
		super(id, name, date, address, balance);
		discount = 0.03;
		CardType = "Basic";
		if (balance <2000)
		{
			
			couponRate = 0.02;
			
		}
		else if ( balance >=2000)
		{
			couponRate = 0.03;
		}
		fullDetail.append("Your annual fee is " + annualfee + "$").append(System.getProperty("line.separator"));
		fullDetail.append("Your coupon rate is " + couponRate + "%").append(System.getProperty("line.separator"));
		
	}




}